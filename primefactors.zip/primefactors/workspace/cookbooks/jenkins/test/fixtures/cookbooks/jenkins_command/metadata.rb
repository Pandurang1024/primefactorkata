name 'jenkins_command'
depends 'jenkins'
