set_unless[:rails][:version]       = false
set_unless[:rails][:environment]   = "production"
set_unless[:rails][:max_pool_size] = 4

#set_unless[:libsqlite3][:version]  = 3.7
