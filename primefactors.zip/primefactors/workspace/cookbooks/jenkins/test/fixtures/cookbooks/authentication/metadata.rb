name 'authentication'
depends 'jenkins'
